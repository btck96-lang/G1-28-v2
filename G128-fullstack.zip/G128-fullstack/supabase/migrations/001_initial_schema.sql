-- ============================================================
-- Genesis 1:28 - Database Schema
-- ============================================================
-- Run this in your Supabase SQL Editor:
-- 1. Go to supabase.com > Your Project > SQL Editor
-- 2. Paste this entire file
-- 3. Click "Run"
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- PROFILES (extends Supabase auth.users)
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  department TEXT DEFAULT 'IT',
  position TEXT DEFAULT 'Staff',
  role TEXT DEFAULT 'staff' CHECK (role IN (
    'super_admin', 'board', 'c_level', 'director', 'manager',
    'team_lead', 'senior', 'staff', 'junior', 'intern', 'contractor', 'viewer'
  )),
  business_unit TEXT DEFAULT 'CT',
  phone TEXT,
  avatar_url TEXT,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
  date_joined DATE DEFAULT CURRENT_DATE,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Auto-create profile when user signs up
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, name, department, role, position)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'department', 'IT'),
    COALESCE(NEW.raw_user_meta_data->>'role', 'staff'),
    COALESCE(NEW.raw_user_meta_data->>'position', 'Staff')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- TASK ENTRIES (IETL daily work log)
-- ============================================================
CREATE TABLE IF NOT EXISTS task_entries (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  task_number SERIAL,
  category TEXT DEFAULT 'IETL-DW',
  task_code TEXT,
  task_verb TEXT,
  task_product TEXT,
  task_qty INTEGER DEFAULT 1,
  description TEXT,
  manhours INTEGER DEFAULT 0,          -- in minutes
  status TEXT DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'Completed')),
  cos_value DECIMAL(12,2) DEFAULT 0,
  sales_value DECIMAL(12,2) DEFAULT 0,
  remarks TEXT,
  screenshot_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_task_entries_user_date ON task_entries(user_id, date);
CREATE INDEX IF NOT EXISTS idx_task_entries_date ON task_entries(date);

-- ============================================================
-- CLOCK RECORDS (attendance)
-- ============================================================
CREATE TABLE IF NOT EXISTS clock_records (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  clock_in TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  clock_out TIMESTAMPTZ,
  total_minutes INTEGER GENERATED ALWAYS AS (
    CASE WHEN clock_out IS NOT NULL 
      THEN EXTRACT(EPOCH FROM (clock_out - clock_in)) / 60 
      ELSE NULL 
    END
  ) STORED,
  auto_clock_in BOOLEAN DEFAULT FALSE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_clock_records_user_date ON clock_records(user_id, date);

-- ============================================================
-- TASK LIBRARY (Verbs)
-- ============================================================
CREATE TABLE IF NOT EXISTS task_verbs (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  verb TEXT UNIQUE NOT NULL,
  description TEXT,
  category TEXT,
  color TEXT DEFAULT 'blue',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PRODUCT LIBRARY
-- ============================================================
CREATE TABLE IF NOT EXISTS task_products (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  category TEXT,
  description TEXT,
  linked_module TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- AUDIT LOG
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_log (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  details JSONB DEFAULT '{}',
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_created ON audit_log(created_at DESC);

-- ============================================================
-- LEAVE REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS leave_requests (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  leave_type TEXT NOT NULL CHECK (leave_type IN ('annual', 'medical', 'emergency', 'unpaid', 'maternity', 'paternity')),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days INTEGER NOT NULL,
  reason TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  approved_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- DOCUMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS documents (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_type TEXT,
  file_size INTEGER,
  folder TEXT DEFAULT 'general',
  tags TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  message TEXT,
  type TEXT DEFAULT 'info' CHECK (type IN ('info', 'success', 'warning', 'error')),
  is_read BOOLEAN DEFAULT FALSE,
  link TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);

-- ============================================================
-- ROW LEVEL SECURITY (RLS) - Protects data per user
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE clock_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_verbs ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_products ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can read all profiles, edit only their own
CREATE POLICY "Profiles are viewable by all authenticated users"
  ON profiles FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id);

-- Task Entries: Users see own tasks, admins see all
CREATE POLICY "Users can view own tasks"
  ON task_entries FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('super_admin', 'board', 'c_level', 'director', 'manager')
  ));

CREATE POLICY "Users can create own tasks"
  ON task_entries FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own tasks"
  ON task_entries FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own tasks"
  ON task_entries FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- Clock Records: Same pattern as tasks
CREATE POLICY "Users can view own clock records"
  ON clock_records FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('super_admin', 'board', 'c_level', 'director', 'manager')
  ));

CREATE POLICY "Users can create own clock records"
  ON clock_records FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own clock records"
  ON clock_records FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- Audit Log: Admins only
CREATE POLICY "Admins can view audit log"
  ON audit_log FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('super_admin', 'board', 'c_level')
  ));

CREATE POLICY "Any authenticated user can insert audit log"
  ON audit_log FOR INSERT TO authenticated WITH CHECK (true);

-- Leave Requests
CREATE POLICY "Users can view own leave requests"
  ON leave_requests FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('super_admin', 'board', 'c_level', 'director', 'manager')
  ));

CREATE POLICY "Users can create own leave requests"
  ON leave_requests FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Documents
CREATE POLICY "Users can view own documents"
  ON documents FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can upload own documents"
  ON documents FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own documents"
  ON documents FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- Notifications
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- Task Verbs & Products: Viewable by all, editable by admins
CREATE POLICY "Task verbs viewable by all"
  ON task_verbs FOR SELECT TO authenticated USING (true);

CREATE POLICY "Task products viewable by all"
  ON task_products FOR SELECT TO authenticated USING (true);

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
-- Run these separately in the Supabase dashboard > Storage

-- INSERT INTO storage.buckets (id, name, public) VALUES ('screenshots', 'screenshots', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);

-- ============================================================
-- SEED DATA - Task Verbs
-- ============================================================
INSERT INTO task_verbs (verb, description, category, color) VALUES
  ('Analyze', 'Examine in detail', 'Analysis', 'purple'),
  ('Approve', 'Authorize or confirm', 'Quality', 'emerald'),
  ('Calculate', 'Compute or figure', 'Analysis', 'lime'),
  ('Compile', 'Gather and organize', 'Documentation', 'sky'),
  ('Coordinate', 'Organize or arrange', 'Management', 'violet'),
  ('Design', 'Create visual layout', 'Creation', 'fuchsia'),
  ('Develop', 'Build or create', 'Creation', 'blue'),
  ('Draft', 'Create initial version', 'Creation', 'cyan'),
  ('Edit', 'Modify or correct', 'Modification', 'amber'),
  ('Follow-up', 'Check status or remind', 'Execution', 'rose'),
  ('Log', 'Record or document', 'Documentation', 'slate'),
  ('Prepare', 'Create or make ready', 'Creation', 'blue'),
  ('Process', 'Handle or deal with', 'Execution', 'green'),
  ('Review', 'Examine or assess', 'Quality', 'purple'),
  ('Send', 'Dispatch or transmit', 'Execution', 'pink'),
  ('Submit', 'Send for approval', 'Execution', 'indigo'),
  ('Update', 'Refresh or revise', 'Modification', 'orange'),
  ('Verify', 'Confirm accuracy', 'Quality', 'teal')
ON CONFLICT (verb) DO NOTHING;

-- ============================================================
-- SEED DATA - Task Products
-- ============================================================
INSERT INTO task_products (code, name, category, description) VALUES
  ('ATT', 'Attendance', 'HR', 'Attendance record'),
  ('EML', 'Email', 'Communication', 'Email correspondence'),
  ('SI', 'Sales Invoice', 'Sales', 'Sales invoice document'),
  ('SQ', 'Sales Quotation', 'Sales', 'Sales quotation document'),
  ('PO', 'Purchase Order', 'Procurement', 'Purchase order document'),
  ('DO', 'Delivery Order', 'Logistics', 'Goods delivery document'),
  ('RPT', 'Report', 'Documentation', 'Report document'),
  ('MOM', 'Minutes of Meeting', 'Documentation', 'Meeting minutes'),
  ('RFQ', 'Request for Quotation', 'Procurement', 'RFQ document'),
  ('LTR', 'Letter', 'Communication', 'Official letter'),
  ('CN', 'Credit Note', 'Finance', 'Credit adjustment'),
  ('DN', 'Debit Note', 'Finance', 'Debit adjustment'),
  ('CLM', 'Claim', 'Finance', 'Expense claim'),
  ('PPT', 'Presentation', 'Documentation', 'Presentation slides'),
  ('STAT', 'Status Report', 'Documentation', 'Status report'),
  ('CTR', 'Contract', 'Legal', 'Contract document'),
  ('PROP', 'Proposal', 'Sales', 'Business proposal')
ON CONFLICT (code) DO NOTHING;

-- ============================================================
-- DONE! Your database is ready.
-- ============================================================
