import { useEffect, useState } from 'react';
import { supabase, getSession, getUserProfile, onAuthChange } from '../lib/supabase';
import { useAppStore } from '../lib/store';

// ============================================================
// useAuth - Manages authentication state
// ============================================================
export function useAuth() {
  const { user, profile, setUser, setProfile, isLoggedIn } = useAppStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check existing session on mount
    const initAuth = async () => {
      try {
        const session = await getSession();
        if (session?.user) {
          setUser(session.user);
          const prof = await getUserProfile(session.user.id);
          setProfile(prof);
        }
      } catch (err) {
        console.error('Auth init error:', err);
      } finally {
        setLoading(false);
      }
    };

    initAuth();

    // Listen for auth changes (login, logout, token refresh)
    const { data: { subscription } } = onAuthChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        setUser(session.user);
        try {
          const prof = await getUserProfile(session.user.id);
          setProfile(prof);
        } catch (err) {
          console.error('Profile fetch error:', err);
        }
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  return { user, profile, isLoggedIn, loading };
}

// ============================================================
// useTasks - Fetches and manages task entries
// ============================================================
export function useTasks(date) {
  const { user, tasks, setTasks } = useAppStore();
  const [loading, setLoading] = useState(false);

  const fetchTasks = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('task_entries')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', date)
        .order('created_at');
      if (error) throw error;
      setTasks(data || []);
    } catch (err) {
      console.error('Fetch tasks error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();

    // Real-time subscription
    const channel = supabase
      .channel('my-tasks')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'task_entries',
        filter: `user_id=eq.${user?.id}`,
      }, () => {
        fetchTasks(); // Refetch on any change
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [user?.id, date]);

  return { tasks, loading, refetch: fetchTasks };
}

// ============================================================
// useClock - Manages clock in/out
// ============================================================
export function useClock() {
  const { user, activeClockIn, setActiveClockIn, clockHistory, setClockHistory } = useAppStore();

  useEffect(() => {
    if (!user) return;

    const fetchClock = async () => {
      const today = new Date().toISOString().split('T')[0];
      
      // Get active clock-in
      const { data: active } = await supabase
        .from('clock_records')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', today)
        .is('clock_out', null)
        .maybeSingle();
      
      setActiveClockIn(active);

      // Get recent history
      const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
      const { data: history } = await supabase
        .from('clock_records')
        .select('*')
        .eq('user_id', user.id)
        .gte('date', thirtyDaysAgo)
        .order('date', { ascending: false });
      
      setClockHistory(history || []);
    };

    fetchClock();
  }, [user?.id]);

  const doClockIn = async () => {
    const { data, error } = await supabase
      .from('clock_records')
      .insert({
        user_id: user.id,
        date: new Date().toISOString().split('T')[0],
        clock_in: new Date().toISOString(),
      })
      .select()
      .single();
    if (!error) setActiveClockIn(data);
    return { data, error };
  };

  const doClockOut = async () => {
    if (!activeClockIn) return;
    const { data, error } = await supabase
      .from('clock_records')
      .update({ clock_out: new Date().toISOString() })
      .eq('id', activeClockIn.id)
      .select()
      .single();
    if (!error) setActiveClockIn(null);
    return { data, error };
  };

  return { activeClockIn, clockHistory, doClockIn, doClockOut };
}

// ============================================================
// useTeamTasks - Admin: view all team members' tasks
// ============================================================
export function useTeamTasks(date) {
  const { profile, teamTasks, setTeamTasks, teamMembers, setTeamMembers } = useAppStore();
  const [loading, setLoading] = useState(false);
  const isAdmin = ['super_admin', 'board', 'c_level', 'director', 'manager'].includes(profile?.role);

  useEffect(() => {
    if (!isAdmin) return;

    const fetchTeam = async () => {
      setLoading(true);
      try {
        // Get all team members
        const { data: members } = await supabase
          .from('profiles')
          .select('*')
          .eq('status', 'active')
          .order('name');
        setTeamMembers(members || []);

        // Get all tasks for today
        const { data: tasks } = await supabase
          .from('task_entries')
          .select(`*, profiles:user_id (name, department, role)`)
          .eq('date', date)
          .order('created_at');
        setTeamTasks(tasks || []);
      } catch (err) {
        console.error('Fetch team error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchTeam();

    // Real-time subscription for team tasks
    const channel = supabase
      .channel('team-tasks')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'task_entries',
        filter: `date=eq.${date}`,
      }, () => fetchTeam())
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [isAdmin, date]);

  return { teamTasks, teamMembers, loading, isAdmin };
}
