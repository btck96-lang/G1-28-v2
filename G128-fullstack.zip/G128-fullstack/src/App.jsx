import React, { useEffect } from 'react';
import { useAuth } from './hooks/useData';
import { useAppStore } from './lib/store';

// ============================================================
// IMPORTANT: This App.jsx is the NEW entry point that uses
// Supabase for backend. Your original MSPAModern.jsx is kept
// as the main UI component - it just needs the data wired in.
//
// For now, this file renders MSPAModern directly.
// When you connect Supabase, uncomment the auth logic below.
// ============================================================

// Import original app (still works standalone with localStorage)
import MSPAModern from './MSPAModern';

export default function App() {
  // Uncomment these when Supabase is connected:
  // const { user, profile, isLoggedIn, loading } = useAuth();
  // if (loading) return <LoadingScreen />;

  return <MSPAModern />;
}

// Loading screen component
function LoadingScreen() {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <h2 className="text-white text-xl font-medium">Genesis 1:28</h2>
        <p className="text-slate-400 text-sm mt-2">Loading your workspace...</p>
      </div>
    </div>
  );
}
